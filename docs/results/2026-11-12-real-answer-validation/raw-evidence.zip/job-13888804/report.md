# Real Answer Completion Validation

five-question idle diagnostic; no routing or population accuracy claim

| N | Thinking budget | Observed / planned | Completed | Correct | Within 87s | Correct within 87s |
|---|---|---|---|---|---|---|
| 1 | 0 | 5 / 5 | 4 | 1 | 4 | 1 |
| 4 | 0 | 5 / 5 | 5 | 3 | 5 | 3 |
| 1 | 2048 | 5 / 5 | 5 | 3 | 5 | 3 |

Inspect raw.jsonl for finish reasons, cap hits, missing boxes, two-stage timings and failed requests. Hardware differs from previous T4 trials if this runs on the school cluster; do not pool latency results.
